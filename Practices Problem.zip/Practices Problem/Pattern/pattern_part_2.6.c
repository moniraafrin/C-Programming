#include<stdio.h>
int main()
{
     int n,i,j,k;
     printf("Enter the value of N: ");
     scanf("%d",&n);

     int count = 1;

     for(i = 1; i <= n; i++)
     {
       for(j = 1; j <= i; j++)
       {
           printf("%d", count++);

       }
       printf("\n");
     }

}
